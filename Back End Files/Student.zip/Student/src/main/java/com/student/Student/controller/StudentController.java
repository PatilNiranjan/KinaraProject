package com.student.Student.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.student.Student.module.Student;
import com.student.Student.repo.Studentrepo;
import com.student.Student.service.StudentService;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.annotation.PostConstruct;


@CrossOrigin
@RestController
public class StudentController {
	
	@Autowired
	Studentrepo repo;

    @Autowired
    private StudentService service;
    
//    To Generate 100 number of dummy students details.
//    @PostConstruct
//    public void initialdb() {
//    List<Student> students = IntStream.range(1, 100)
//    		.mapToObj(i -> new Student("Student"+i, new Random().nextInt(100),"College"+i))
//    		.collect(Collectors.toList());
//    		repo.saveAll(students);
//    }
    
    
    @GetMapping("/getAllStudent")
    ResponseEntity<List<Student>> getAll()
    {
    	return new ResponseEntity<List<Student>>(service.findAllStudent(),HttpStatus.FOUND);
    }
    
    @GetMapping("/getSortedStudent")
    ResponseEntity<List<Student>> findStudentWithSorting(String feild)
    {
    	return new ResponseEntity<List<Student>>(service.findStudentWithSorting(feild),HttpStatus.FOUND);
    }

    @GetMapping("/getStudentBypagination")
    ResponseEntity<Page<Student>> getStudentBypagination(@RequestHeader int pagenum, @RequestHeader int pagesize )
    {
    	return new ResponseEntity<Page<Student>>(service.findStudentWithPagination(pagenum, pagesize),HttpStatus.FOUND);
    }
    
    @GetMapping("/getStudentBypaginationwithsort")
    ResponseEntity<Page<Student>> getStudentBypaginationwithSort(@RequestHeader int pagenum, @RequestHeader int pagesize, @RequestHeader String field)
    {
    	return new ResponseEntity<Page<Student>>(service.findStudentsWithPaginationAndSorting(pagenum, pagesize, field),HttpStatus.FOUND);
    }
}