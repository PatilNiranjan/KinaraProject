package com.student.Student.module;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Student {
    @Id
    @GeneratedValue
    private  int sid;
    private String sname;
    private int smarks;
    private String college;
    
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getSmarks() {
		return smarks;
	}
	public void setSmarks(int smarks) {
		this.smarks = smarks;
	}
	public String getCollege() {
		return college;
	}
	public void setCollege(String college) {
		this.college = college;
	}
	
//  To Generate 100 number of dummy students details.
	public Student(String sname, int smarks, String college) {
		this.sname = sname;
		this.smarks = smarks;
		this.college = college;
	}
	
	
	

    
    
   
}