package com.student.Student.service;
import com.student.Student.module.Student;
import com.student.Student.repo.Studentrepo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class StudentService {

    @Autowired
    private Studentrepo repository;

    public List<Student> findAllStudent() {
        return repository.findAll();
    }
    
    public List<Student> findStudentWithSorting(String feild){
        return repository.findAll(Sort.by(Sort.Direction.ASC,feild)); 
    }

    public Page<Student> findStudentWithPagination(int offset,int pageSize){
        Page<Student> Students = repository.findAll(PageRequest.of(offset, pageSize));
        return  Students;
    }

    public Page<Student> findStudentsWithPaginationAndSorting(int offset,int pageSize,String field){
        Page<Student> Student = repository.findAll(PageRequest.of(offset, pageSize).withSort(Sort.by(field)));
        return  Student;
    }

}